#!/usr/bin/env python3
"""
fix_og_tags.py
Scans every .html file in the repo and makes sure it has a complete
Open Graph / Twitter Card meta block (og:title, og:description,
og:url, og:image, twitter:*).

- If a page has NO og:title at all, a full block is inserted before </head>,
  using the page's existing <title> / <meta name="description"> as source.
- If a page already has og:title/og:description/og:url but is missing
  og:image / twitter:image / twitter:card, only the MISSING tags are
  appended right after the existing og:title tag — nothing is duplicated.

Usage:
    python3 scripts/fix_og_tags.py            # fix in place
    python3 scripts/fix_og_tags.py --check    # dry run, exit 1 if changes needed
"""
import os
import re
import sys
import html

DOMAIN = "https://salarybit.in"
DEFAULT_IMAGE = f"{DOMAIN}/og-image.png"
SITE_NAME = "SalaryBit"
IMG_W, IMG_H = "1200", "630"

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIP_DIRS = {".git", "node_modules", "scripts", "certs", ".github"}

TITLE_RE = re.compile(r"<title>(.*?)</title>", re.IGNORECASE | re.DOTALL)
DESC_RE = re.compile(
    r'<meta\s+name=["\']description["\']\s+content=["\'](.*?)["\']\s*/?>',
    re.IGNORECASE | re.DOTALL,
)
OGTITLE_RE = re.compile(r'<meta\s+property=["\']og:title["\'][^>]*>', re.IGNORECASE)
OGIMAGE_RE = re.compile(r'property=["\']og:image["\']', re.IGNORECASE)
TWIMAGE_RE = re.compile(r'name=["\']twitter:image["\']', re.IGNORECASE)
TWCARD_RE = re.compile(r'name=["\']twitter:card["\']', re.IGNORECASE)
HEAD_CLOSE_RE = re.compile(r"</head>", re.IGNORECASE)


def find_html_files():
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            if fn.endswith(".html"):
                yield os.path.join(dirpath, fn)


def page_url(path):
    rel = os.path.relpath(path, ROOT).replace(os.sep, "/")
    if rel == "index.html":
        return f"{DOMAIN}/"
    if rel.endswith("/index.html"):
        return f"{DOMAIN}/{rel[:-len('index.html')]}"
    return f"{DOMAIN}/{rel}"


def full_block(title, desc, url):
    title, desc = html.escape(title, quote=True), html.escape(desc, quote=True)
    return f"""<meta property="og:type" content="website">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{url}">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:image" content="{DEFAULT_IMAGE}">
<meta property="og:image:width" content="{IMG_W}">
<meta property="og:image:height" content="{IMG_H}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{desc}">
<meta name="twitter:image" content="{DEFAULT_IMAGE}">
"""


def process_file(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    title_match = TITLE_RE.search(content)
    title = html.unescape(title_match.group(1).strip()) if title_match else SITE_NAME

    ogtitle_match = OGTITLE_RE.search(content)

    if not ogtitle_match:
        desc_match = DESC_RE.search(content)
        desc = (
            html.unescape(desc_match.group(1).strip())
            if desc_match
            else f"Free tool from {SITE_NAME} for Indian salaried professionals. No login, no data stored."
        )
        url = page_url(path)
        block = full_block(title, desc, url)
        head_match = HEAD_CLOSE_RE.search(content)
        if not head_match:
            return content, False
        new_content = content[: head_match.start()] + block + content[head_match.start() :]
        return new_content, True

    needs_image = not OGIMAGE_RE.search(content)
    needs_twimage = not TWIMAGE_RE.search(content)
    needs_twcard = not TWCARD_RE.search(content)

    if not (needs_image or needs_twimage or needs_twcard):
        return content, False

    extra = []
    if needs_image:
        extra += [
            f'<meta property="og:image" content="{DEFAULT_IMAGE}">',
            f'<meta property="og:image:width" content="{IMG_W}">',
            f'<meta property="og:image:height" content="{IMG_H}">',
        ]
    if needs_twcard:
        extra.append('<meta name="twitter:card" content="summary_large_image">')
    if needs_twimage:
        extra.append(f'<meta name="twitter:image" content="{DEFAULT_IMAGE}">')

    insert_text = "\n".join(extra)
    insert_pos = ogtitle_match.end()
    new_content = content[:insert_pos] + "\n" + insert_text + content[insert_pos:]
    return new_content, True


def main():
    check_only = "--check" in sys.argv
    changed_files = []

    for path in find_html_files():
        new_content, changed = process_file(path)
        if changed:
            changed_files.append(os.path.relpath(path, ROOT))
            if not check_only:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(new_content)

    if changed_files:
        verb = "Would fix" if check_only else "Fixed"
        print(f"{verb} OG/Twitter tags on {len(changed_files)} file(s):")
        for f in changed_files:
            print(f"  - {f}")
    else:
        print("All pages already have complete OG tags. Nothing to do.")

    if check_only and changed_files:
        sys.exit(1)


if __name__ == "__main__":
    main()
